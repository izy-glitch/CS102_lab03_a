public interface Selectable{

    public boolean getSelected();
    public void setSelected( boolean selected );
    public Shape contains( int x, int y );
}
