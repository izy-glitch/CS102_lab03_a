public interface Locatable{

    public void setLocation( int x, int y );
    public int getX();
    public int getY();

}
